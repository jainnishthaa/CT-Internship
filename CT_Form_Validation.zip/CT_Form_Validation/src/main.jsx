import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './index.css'
import './style.css'
import FormProvider from './context/formContext.jsx'
import { BrowserRouter, Route, Router } from 'react-router-dom'
import Form from './components/Form.jsx'

ReactDOM.createRoot(document.getElementById('root')).render(
    <BrowserRouter>
    <App/>
    </BrowserRouter>
);
