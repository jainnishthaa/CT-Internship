import React, { createContext, useContext } from 'react'
import { useState } from 'react';

export const FormContext=React.createContext();
export const useForm = () => useContext(FormContext);

const FormProvider = ({children}) => {
    const [formData, setFormData]=useState({})
    return (
        <FormContext.Provider value={{formData, setFormData}}>
            {children}
        </FormContext.Provider>
    )
}

export default FormProvider