import React from "react";
import { useForm } from "../context/formContext";

const Summary = () => {
  const { formData } = useForm();
  return (
    <div>
      <h1>Summary</h1>
      <p>First Name: {formData.firstName}</p>
      <p>Last Name: {formData.lastName}</p>
      <p>Email: {formData.email}</p>
      <p>Phone: {formData.phoneNumber}</p>
      <p>Address: {formData.address}</p>
      <p>City: {formData.city}</p>
      <p>State: {formData.state}</p>
      <p>Aadhar Number: {formData.aadharNumber}</p>
      <p>PAN Number: {formData.panNumber}</p>
    </div>
  );
};

export default Summary;
