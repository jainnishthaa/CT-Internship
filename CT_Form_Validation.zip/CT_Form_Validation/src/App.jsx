import { useState } from "react";
import reactLogo from "./assets/react.svg";
import viteLogo from "/vite.svg";
import "./App.css";
import FormProvider from "./context/formContext";
import { Route, Routes } from "react-router-dom";
import Form from "./components/Form";
import Summary from "./components/Summary";

function App() {
  const [count, setCount] = useState(0);

  return (
    <FormProvider>
      <Routes>
        <Route path="/" element={<Form/>} />
        <Route path="/summary" element={<Summary/>} />
      </Routes>
    </FormProvider>
  );
}

export default App;
