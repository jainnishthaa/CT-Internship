import React, { useState } from "react";
import { useForm } from "../context/formContext";
import { useNavigate } from "react-router-dom";

const Form = () => {
  const navigate = useNavigate();
  const { setFormData } = useForm();
  const [form, setForm] = useState({
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    confirmPassword: "",
    phoneNumber: "",
    address: "",
    city: "",
    state: "",
    aadharNumber: "",
    panNumber: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const Isvalid = false;
  let error = {};

  const validateFirstName = () => {
    if (!/^[a-zA-Z]{3,}$/.test(form.firstName)) {
      error.firstName =
        "First name must be at least 3 characters and contain only alphabets";
    }
  };
  const validateLastName = () => {
    if (!/^[a-zA-Z]{3,}$/.test(form.lastName)) {
      error.lastName =
        "Last name must be at least 3 characters and contain only alphabets";
    }
  };
  const validateEmail = () => {
    if (!/^[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,4}$/.test(form.email)) {
      error.email = "Email must include @ and domain name";
    }
  };
  const validatePassword = () => {
    if (
      !/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/.test(
        form.password
      )
    ) {
      error.password =
        "Password must be at least 8 characters and contain at least one uppercase letter, one lowercase letter, one number and one special character";
    }
  };
  const validateConfirmPassword = () => {
    if (form.password !== form.confirmPassword) {
      error.confirmPassword = "Password must be same";
    }
  };
  const validatePhoneNumber = () => {
    if (!/^[6-9]\d{9}$/.test(form.phoneNumber)) {
      error.phoneNumber =
        "Phone number must be 10 digits and start with 6,7,8 or 9";
    }
  };
  const validateAddress = () => {
    if (!form.address) {
      error.address = "Address is required";
    }
  };
  const validateCity = () => {
    if (!form.city) {
      error.city = "Please select a city";
    }
  };
  const validateState = () => {
    if (!form.state) {
      error.state = "Please select a state";
    }
  };
  const validateAadharNumber = () => {
    if (!/^\d{12}$/.test(form.aadharNumber)) {
      error.aadharNumber = "Aadhar number must be 12 digits";
    }
  };
  const validatePanNumber = () => {
    if (!/^[A-Z]{5}\d{4}[A-Z]{1}$/.test(form.panNumber)) {
      error.panNumber =
        "PAN number must follow the standard format (five alphabets followed by four numbers followed by one alphabet), must be alphanumeric, no spaces, dashes or special characters allowed";
    }
  };

  const validate = () => {
    validateFirstName();
    validateLastName();
    validateEmail();
    validatePassword();
    validateConfirmPassword();
    validatePhoneNumber();
    validateAddress();
    validateCity();
    validateState();
    validateAadharNumber();
    validatePanNumber();
    return error;
  };

  const handleChange = (e) => {
    setForm({
      ...form,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const error = validate();
    if (Object.keys(error).length === 0) {
      setFormData(form);
      navigate("/summary");
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <h2>User Details Form</h2>

      {/* First Name */}
      <div className="form-group ">
        <label htmlFor="firstName" >First Name:</label>
        <input
          type="text"
          name="firstName"
          id="firstName"
          value={form.firstName}
          onChange={handleChange}
          onBlur={form.firstName && validateFirstName()}
          className={ error.firstName ? "error" : form.firstName ? "success" : ""}
        />
        {error.firstName && (<p className="error-message">{error.firstName}</p>)}
        {form.firstName && !error.firstName && <p className="success-message">Looks good!</p>}
      </div>

      {/* Last Name */}
      <div className="form-group">
        <label htmlFor="lastName" >Last Name:</label>
        <input
          type="text"
          name="lastName"
          id="lastName"
          value={form.lastName}
          onChange={handleChange}
          onBlur={form.lastName && validateLastName()}
          className={ error.lastName ? "error" : form.lastName ? "success" : ""}
        />
        {error.lastName && <p className="error-message">{error.lastName}</p>}
        {form.lastName && !error.lastName && <p className="success-message">Looks good!</p>}
      </div>

      {/* Email */}
      <div className="form-group ">
        <label htmlFor="email">Email:</label>
        <input
          type="email"
          name="email"
          id="email"
          value={form.email}
          onChange={handleChange}
          onBlur={form.email && validateEmail()}
          className={ error.email ? "error" : form.email ? "success" : "" }
        />
        {error.email && <p className="error-message">{error.email}</p>}
        {form.email && !error.email && <p className="success-message">Looks good!</p>}
      </div>

      {/* Password */}
      <div className="form-group " >
        <label htmlFor="password" >Password:</label>
        <input
          type={showPassword ? "text" : "password"}
          name="password"
          id="password"
          value={form.password}
          onChange={handleChange}
          onBlur={form.password && validatePassword()}
          className={ error.password ? "error" : form.password ? "success" : ""}
        />
        <button type="button" onClick={() => setShowPassword(!showPassword)}>
          {showPassword ? "Hide" : "Show"} Password
        </button>
        {error.password && <p className="error-message">{error.password}</p>}
        {form.password && !error.password && <p className="success-message">Looks good!</p>}
      </div>

      {/* Confirm Password */}
      <div className="form-group " >
        <label htmlFor="confirmPassword" >Confirm Password:</label>
        <input
          type="password"
          name="confirmPassword"
          id="confirmPassword"
          value={form.confirmPassword}
          onChange={handleChange}
          onBlur={form.confirmPassword && validateConfirmPassword()}
          className={ error.confirmPassword ? "error" : form.confirmPassword ? "success" : ""}
          disabled={!form.password}
        />
        {error.confirmPassword && (
          <p className="error-message">{error.confirmPassword}</p>
        )}
        {form.confirmPassword && !error.confirmPassword && (
          <p className="success-message">Looks good!</p>
        )}
      </div>

      {/* Phone Number */}
      <div className="form-group " >
        <label htmlFor="phoneNumber" >Phone Number:</label>
        <input
          type="text"
          name="phoneNumber"
          id="phoneNumber"
          value={form.phoneNumber}
          onChange={handleChange}
          onBlur={form.phoneNumber && validatePhoneNumber()}
          className={ error.phoneNumber ? "error" : form.phoneNumber ? "success" : "" }
        />
        {error.phoneNumber && <p className="error-message">{error.phoneNumber}</p>}
        {form.phoneNumber && !error.phoneNumber && ( <p className="success-message">Looks good!</p> )}
      </div>

      {/* Address */}
      <div className="form-group " >
        <label htmlFor="address" >Address:</label>
        <textarea
          name="address"
          id="address"
          value={form.address}
          onChange={handleChange}
          onBlur={form.address && validateAddress()}
          className={error.address ? "error" : form.address ? "success" : "" }
        />
        {error.address && <p className="error-message">{error.address}</p>}
        {form.address && !error.address && ( <p className="success-message">Looks good!</p> )}
      </div>

      {/* City */}
      <div className="form-group ">
        <label htmlFor="city" >City:</label>
        <select
          name="city"
          id="city"
          value={form.city}
          onChange={handleChange}
          onBlur={form.city && validateCity()}
          className={error.city ? "error" : form.city ? "success" : ""}
        >
          <option value="">Select a city</option>
          <option value="Alipur">Alipur</option>
          <option value="Bawana">Bawana</option>
          <option value="Central Delhi">Central Delhi</option>
          <option value="Delhi">Delhi</option>
          <option value="Deoli">Deoli</option>
          <option value="East Delhi">East Delhi</option>
          <option value="Karol Bagh">Karol Bagh</option>
          <option value="Najafgarh">Najafgarh</option>
          <option value="Nangloi Jat">Nangloi Jat</option>
          <option value="Narela">Narela</option>
          <option value="New Delhi">New Delhi</option>
          <option value="North Delhi">North Delhi</option>
          <option value="North East Delhi">North East Delhi</option>
          <option value="North West Delhi">North West Delhi</option>
          <option value="Pitampura">Pitampura</option>
          <option value="Rohini">Rohini</option>
          <option value="South Delhi">South Delhi</option>
          <option value="South West Delhi">South West Delhi</option>
          <option value="West Delhi">West Delhi</option>
        </select>
        {error.city && <p className="error-message">{error.city}</p>}
        {form.city && !error.city && <p className="success-message">looks good!</p>}
      </div>

      {/* State */}
      <div className="form-group " >
        <label htmlFor="state" >State:</label>
        <select
          name="state"
          id="state"
          value={form.state}
          onChange={handleChange}
          onBlur={form.state && validateState()}
          className={ error.state ? "error" : form.state ? "success" : "" }
        >
          <option value="">Select a state</option>
          <option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
          <option value="Andhra Pradesh">Andhra Pradesh</option>
          <option value="Arunachal Pradesh">Arunachal Pradesh</option>
          <option value="Assam">Assam</option>
          <option value="Bihar">Bihar</option>
          <option value="Chandigarh">Chandigarh</option>
          <option value="Chhattisgarh">Chhattisgarh</option>
          <option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
          <option value="Daman and Diu">Daman and Diu</option>
          <option value="Delhi">Delhi</option>
          <option value="Goa">Goa</option>
          <option value="Gujarat">Gujarat</option>
          <option value="Haryana">Haryana</option>
          <option value="Himachal Pradesh">Himachal Pradesh</option>
          <option value="Jammu and Kashmir">Jammu and Kashmir</option>
          <option value="Jharkhand">Jharkhand</option>
          <option value="Karnataka">Karnataka</option>
          <option value="Kerala">Kerala</option>
          <option value="Ladakh">Ladakh</option>
          <option value="Lakshadweep">Lakshadweep</option>
          <option value="Madhya Pradesh">Madhya Pradesh</option>
          <option value="Maharashtra">Maharashtra</option>
          <option value="Manipur">Manipur</option>
          <option value="Meghalaya">Meghalaya</option>
          <option value="Mizoram">Mizoram</option>
          <option value="Nagaland">Nagaland</option>
          <option value="Odisha">Odisha</option>
          <option value="Puducherry">Puducherry</option>
          <option value="Punjab">Punjab</option>
          <option value="Rajasthan">Rajasthan</option>
          <option value="Sikkim">Sikkim</option>
          <option value="Tamil Nadu">Tamil Nadu</option>
          <option value="Telangana">Telangana</option>
          <option value="Tripura">Tripura</option>
          <option value="Uttar Pradesh">Uttar Pradesh</option>
          <option value="Uttarakhand">Uttarakhand</option>
          <option value="West Bengal">West Bengal</option>
        </select>
        {error.state && <p className="error-message">{error.state}</p>}
        {form.state && !error.state && <p className="success-message">Looks good!</p>}
      </div>

      {/* Aadhar Number */}
      <div className="form-group " >
        <label htmlFor="aadharNumber" >Aadhar Number:</label>
        <input
          type="text"
          name="aadharNumber"
          id="aadharNumber"
          value={form.aadharNumber}
          onChange={handleChange}
          onBlur={form.aadharNumber && validateAadharNumber()}
          className={ error.aadharNumber ? "error" : form.aadharNumber ? "success" : "" }
        />
        {error.aadharNumber && ( <p className="error-message">{error.aadharNumber}</p> )}
        {form.aadharNumber && !error.aadharNumber && ( <p className="success-message">Looks good!</p> )}
      </div>

      {/* PAN Number */}
      <div className="form-group " >
        <label htmlFor="panNumber" >PAN Number:</label>

        <input
          type="text"
          name="panNumber"
          id="panNumber"
          value={form.panNumber}
          onChange={handleChange}
          onBlur={form.panNumber && validatePanNumber()}
          className={ error.panNumber ? "error" : form.panNumber ? "success" : "" }
        />
        {error.panNumber && <p className="error-message">{error.panNumber}</p>}
        {form.panNumber && !error.panNumber && <p className="success-message">Looks good </p>}
      </div>

      <div className="form-group save">
        <button type="submit" disabled={!form.panNumber || Object.keys(error).length > 0}>
          Save
        </button>
      </div>
    </form>
  );
};

export default Form;
